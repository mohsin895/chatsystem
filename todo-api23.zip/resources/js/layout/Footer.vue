<template>
    <div class="footer"><h1>Footer</h1></div>
</template>
<style lang="css" scoped>
@media print {
           
           .footer {
           display: none;
   }

 }
</style>