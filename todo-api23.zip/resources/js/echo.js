// src/services/echo.js
import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

export const initializeEcho = () => {
  // Clear any existing Pusher/Echo instances
  window.Pusher = Pusher;
  
  if (window.Echo) {
    // Clean up existing Echo instance
    if (window.Echo.connector && window.Echo.connector.channels) {
      Object.keys(window.Echo.connector.channels.channels || {}).forEach(channel => {
        window.Echo.leave(channel);
      });
    }
    window.Echo = null;
  }
  
  const token = localStorage.getItem('token');
  if (!token) {
    console.error('No authentication token found');
    return null;
  }
  
  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
  
  try {
    window.Echo = new Echo({
      broadcaster: 'reverb',
      key: import.meta.env.VITE_REVERB_APP_KEY,
      wsHost: import.meta.env.VITE_REVERB_HOST || window.location.hostname,
      wsPort: parseInt(import.meta.env.VITE_REVERB_PORT) || 8080,
      wsPath: import.meta.env.VITE_REVERB_PATH || '',
      forceTLS: false,
      disableStats: true,
      enabledTransports: ['ws', 'wss'],
      auth: {
        headers: {
          'Authorization': `Bearer ${token}`,
          'X-CSRF-TOKEN': csrfToken,
          'Accept': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        }
      },
      authEndpoint: '/api/broadcasting/auth',
    });
    
    console.log('Echo initialized successfully');
    return window.Echo;
  } catch (error) {
    console.error('Failed to initialize Echo:', error);
    return null;
  }
};

// Setup listeners for debug purposes (remove in production)
export const setupDebugListeners = () => {
  if (!window.Echo) return;
  
  window.Echo.connector.pusher.connection.bind('connected', () => {
    console.log('Successfully connected to Reverb.');
  });
  
  window.Echo.connector.pusher.connection.bind('disconnected', () => {
    console.log('Disconnected from Reverb.');
  });
  
  window.Echo.connector.pusher.connection.bind('error', (err) => {
    console.error('Reverb connection error:', err);
  });
};

export default {
  initializeEcho,
  setupDebugListeners
};