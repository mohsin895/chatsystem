<?php

use Illuminate\Support\Facades\Broadcast;

// Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
//     return (int) $user->id === (int) $id;
// });

// In channels.php
Broadcast::routes(['middleware' => ['auth:sanctum']]);

Broadcast::channel('chat.user.{userId}', function ($user, $userId) {
    return (int) $user->id === (int) $userId || $user->role === 1;
});

Broadcast::channel('chat.admin.{userId}', function ($user, $userId) {
    // Allow admin access to any user channel
    if ($user->role === 1) {
        return true;
    }
    // Allow users to access their own channel
    return (int) $user->id === (int) $userId;
});