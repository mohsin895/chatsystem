<template>
    <div><h1>Not found</h1></div>
</template>