<template>
    <div class="bg-dark p-6">
     
    </div>
  </template>
  <script setup>
  
  </script>