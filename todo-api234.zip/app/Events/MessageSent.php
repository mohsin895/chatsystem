<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use App\Models\Message;

class MessageSent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message;

    public function __construct(Message $message)
    {
        $this->message = $message;
    }

    public function broadcastOn()
    {
        // Broadcast to both parties
        return [
            new PrivateChannel('chat.user.' . $this->message->receiver_id),
            new PrivateChannel('chat.admin.' . $this->message->sender_id)
        ];
    }

    public function broadcastWith()
    {
        return [
            'id' => $this->message->id,
            'text' => $this->message->text,
            'sender_id' => $this->message->sender_id,
            'receiver_id' => $this->message->receiver_id,
            'time' => $this->message->created_at->format('h:i A'),
            'is_admin' => $this->message->sender->role === 1,
            'status' => 'delivered',
            'timestamp' => $this->message->created_at->toDateTimeString()
        ];
    }
}